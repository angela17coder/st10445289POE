package Registration;

import javax.swing.JOptionPane;

public class LOGIN {
    private String usernameErrorMsg = "";
    private String phoneErrorMsg = "";
    
    public String getUsernameErrorMsg() {
        return usernameErrorMsg;
    }

    public String getPhoneErrorMsg() {
        return phoneErrorMsg;
    }

    public String registerUser(String password, String username) {
        return "User registered successfully!"; //0760989319
    }

    // Username: max 5 characters & contains "_"
    public boolean checkUserName(String username) {
        usernameErrorMsg = "";
        if (username.length() > 5) {
            usernameErrorMsg += "- Username must not exceed 5 characters\n";
        }
        if (!username.contains("_")) {
            usernameErrorMsg += "- Username must contain an underscore (_)\n";
        }
        return usernameErrorMsg.isEmpty();
    }

    public boolean checkPasswordComplexity(String password) {
        return password.matches("^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$");
    }

    public boolean checkPhoneNumberFormat(String phone) {
        phoneErrorMsg = "";
        if (!phone.startsWith("+27")) {
            phoneErrorMsg += "- Phone number must start with country code +27\n";
        }
        if (!phone.matches("\\+27\\d{9}")) {
            phoneErrorMsg += "- Phone number must be +27 followed by exactly 9 digits\n";
        }
        return phoneErrorMsg.isEmpty();
    }

    public boolean loginUser(boolean isUsernameValid, boolean isPasswordValid, String password, String username) {
        return isUsernameValid && isPasswordValid;
    }

    public String returnLoginStatus(boolean status, String username, String password) {
        return status ? "Login successful! Welcome, " + username + "!" : "Login failed.";
    }
    public static void main(String[] args) {
    LOGIN login = new LOGIN();

    String username = JOptionPane.showInputDialog("Enter username (atleast 5 chars, must contain '_'):");
    boolean isUsernameValid = login.checkUserName(username);
    if (!isUsernameValid) {
        JOptionPane.showMessageDialog(null, "Username Error:\n" + login.getUsernameErrorMsg());
        return;
    }
    

    String password = JOptionPane.showInputDialog("Enter password (min 8 chars, with uppercase, lowercase, digit, special char):");
    boolean isPasswordValid = login.checkPasswordComplexity(password);
    if (!isPasswordValid) {
        JOptionPane.showMessageDialog(null, """
            Password must meet the following:
            - At least 8 characters
            - One uppercase letter
            - One lowercase letter
            - One digit
            - One special character (@#$%^&+=!)
        """);
        return;
    }

    String phone = JOptionPane.showInputDialog("Enter phone number (Format: +27XXXXXXXXX):");
    boolean isPhoneValid = login.checkPhoneNumberFormat(phone);
    if (!isPhoneValid) {
        JOptionPane.showMessageDialog(null, "Phone Number Error:\n" + login.getPhoneErrorMsg());
        return;
    }

    String registerMsg = login.registerUser(password, username);
    JOptionPane.showMessageDialog(null, registerMsg);

    boolean loginStatus = login.loginUser(isUsernameValid, isPasswordValid, password, username);
    String loginMsg = login.returnLoginStatus(loginStatus, username, password);
    JOptionPane.showMessageDialog(null, loginMsg);
}

}

