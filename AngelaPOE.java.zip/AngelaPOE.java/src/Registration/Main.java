package Registration;

import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        LOGIN login = new LOGIN();
        
        String username = JOptionPane.showInputDialog("Enter username (atleast 5 chars, must contain '_'):");
        login.checkUserName(username);
        
        String password = JOptionPane.showInputDialog("Password must be at least 8 characters, include an uppercase letter, number, and special character\n");
        login.checkPasswordComplexity(password);
        
        String num = JOptionPane.showInputDialog("Put in your cellphone number (+27):");
        login.checkPhoneNumberFormat("Enter phone number (Format: +27XXXXXXXXX):");
        
        //String username = JOptionPane.showInputDialog("Enter username:");
        //String password = JOptionPane.showInputDialog("Enter password:");
        //String num = JOptionPane.showInputDialog("Put in your cellphone number (+27):");

        // Validate all inputs
        boolean isUsernameValid = login.checkUserName(username);
        boolean isPasswordValid = login.checkPasswordComplexity(password);
        boolean isPhoneValid = login.checkPhoneNumberFormat(num);

        if (!isUsernameValid || !isPasswordValid || !isPhoneValid) {
            String errorMsg = "Registration failed due to the following:\n";
            if (!isUsernameValid) errorMsg += login.getUsernameErrorMsg() + "\n";
            if (!isPasswordValid) errorMsg += "Password must be at least 8 characters, include an uppercase letter, number, and special character\n";
            if (!isPhoneValid) errorMsg += login.getPhoneErrorMsg();
            JOptionPane.showMessageDialog(null, errorMsg);
            return;
        }

        // Register the user
        String registrationMsg = login.registerUser(password, username);
        JOptionPane.showMessageDialog(null, registrationMsg);

        // Proceed to login
        boolean loginStatus = login.loginUser(isUsernameValid, isPasswordValid, password, username);
        String loginMessage = login.returnLoginStatus(loginStatus, username, password);
        JOptionPane.showMessageDialog(null, loginMessage);
    }
    
}
